const CharityChain = artifacts.require("CharityChain");

module.exports = function (deployer) {
 deployer.deploy(CharityChain);
};